/*******************************************************************************
* File Name: StepperOutCtrl_PM.c
* Version 1.80
*
* Description:
*  This file contains the setup, control, and status commands to support 
*  the component operation in the low power mode. 
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "StepperOutCtrl.h"

/* Check for removal by optimization */
#if !defined(StepperOutCtrl_Sync_ctrl_reg__REMOVED)

static StepperOutCtrl_BACKUP_STRUCT  StepperOutCtrl_backup = {0u};

    
/*******************************************************************************
* Function Name: StepperOutCtrl_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void StepperOutCtrl_SaveConfig(void) 
{
    StepperOutCtrl_backup.controlState = StepperOutCtrl_Control;
}


/*******************************************************************************
* Function Name: StepperOutCtrl_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*
*******************************************************************************/
void StepperOutCtrl_RestoreConfig(void) 
{
     StepperOutCtrl_Control = StepperOutCtrl_backup.controlState;
}


/*******************************************************************************
* Function Name: StepperOutCtrl_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component for entering the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void StepperOutCtrl_Sleep(void) 
{
    StepperOutCtrl_SaveConfig();
}


/*******************************************************************************
* Function Name: StepperOutCtrl_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component after waking up from the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void StepperOutCtrl_Wakeup(void)  
{
    StepperOutCtrl_RestoreConfig();
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
