/*******************************************************************************
* File Name: isr_ButtonPress.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_isr_ButtonPress_H)
#define CY_ISR_isr_ButtonPress_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void isr_ButtonPress_Start(void);
void isr_ButtonPress_StartEx(cyisraddress address);
void isr_ButtonPress_Stop(void);

CY_ISR_PROTO(isr_ButtonPress_Interrupt);

void isr_ButtonPress_SetVector(cyisraddress address);
cyisraddress isr_ButtonPress_GetVector(void);

void isr_ButtonPress_SetPriority(uint8 priority);
uint8 isr_ButtonPress_GetPriority(void);

void isr_ButtonPress_Enable(void);
uint8 isr_ButtonPress_GetState(void);
void isr_ButtonPress_Disable(void);

void isr_ButtonPress_SetPending(void);
void isr_ButtonPress_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the isr_ButtonPress ISR. */
#define isr_ButtonPress_INTC_VECTOR            ((reg32 *) isr_ButtonPress__INTC_VECT)

/* Address of the isr_ButtonPress ISR priority. */
#define isr_ButtonPress_INTC_PRIOR             ((reg32 *) isr_ButtonPress__INTC_PRIOR_REG)

/* Priority of the isr_ButtonPress interrupt. */
#define isr_ButtonPress_INTC_PRIOR_NUMBER      isr_ButtonPress__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable isr_ButtonPress interrupt. */
#define isr_ButtonPress_INTC_SET_EN            ((reg32 *) isr_ButtonPress__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the isr_ButtonPress interrupt. */
#define isr_ButtonPress_INTC_CLR_EN            ((reg32 *) isr_ButtonPress__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the isr_ButtonPress interrupt state to pending. */
#define isr_ButtonPress_INTC_SET_PD            ((reg32 *) isr_ButtonPress__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the isr_ButtonPress interrupt. */
#define isr_ButtonPress_INTC_CLR_PD            ((reg32 *) isr_ButtonPress__INTC_CLR_PD_REG)



#endif /* CY_ISR_isr_ButtonPress_H */


/* [] END OF FILE */
